package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.StatusDTO;
import com.example.demo.dto.UserRegisterDTO;
import com.example.demo.dto.UserResponseDTO;
import com.example.demo.dto.UserUpdateDTO;

public interface IUserService {
	
	public StatusDTO<UserResponseDTO> createUser(UserRegisterDTO userRegisterDTO);
	public List<UserResponseDTO> getAllUsers();
	public StatusDTO<UserResponseDTO> getUserById(Long id);
	public StatusDTO<UserResponseDTO> updateUser(UserUpdateDTO userUpdateDTO, Long id);
	public boolean deleteUserById(Long id);
	public void deleteAllUsers();

}
