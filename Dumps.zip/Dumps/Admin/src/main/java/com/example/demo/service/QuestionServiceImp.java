package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.example.demo.dto.EmailDTO;
import com.example.demo.dto.QuestionRequestDTO;
import com.example.demo.dto.QuestionResponseDTO;
import com.example.demo.dto.QuestionUpdateDTO;
import com.example.demo.dto.StatusDTO;
import com.example.demo.entity.Question;
import com.example.demo.repository.QuestionRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.util.Utilities;

@Service
public class QuestionServiceImp implements IQuestionService {
	
	@Value("${enable-notification-emails:true}")
	private boolean enableNotificationEmails;
	
	@Autowired
	private QuestionRepository questionRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	
	@Autowired
    private JavaMailSender mailSender;
	
	@Autowired
	private Utilities utilities;
	
	@Override
	public StatusDTO<List<QuestionResponseDTO>> getAllQuestions(String status, String search, String topic) {
		if (search == null && topic == null) {
			if (status.equalsIgnoreCase("all")) {
				return new StatusDTO<List<QuestionResponseDTO>>("", true, utilities.convertQuestionListToQuestionResponseDTOList(questionRepository.findAll()));
			}
			else if (status.equalsIgnoreCase("approved")) {
				return new StatusDTO<List<QuestionResponseDTO>>("", true, utilities.convertQuestionListToQuestionResponseDTOList(questionRepository.findByIsApprovedTrue()));
			}
			else if (status.equalsIgnoreCase("unapproved")) {
				return new StatusDTO<List<QuestionResponseDTO>>("", true, utilities.convertQuestionListToQuestionResponseDTOList(questionRepository.findByIsApprovedFalse()));
			}
			else {
				return new StatusDTO<List<QuestionResponseDTO>>("Provided invalid status. Should be one of 'all', 'approved' or 'unapproved'.", false, null);
			}
		}
		else if (search != null && topic == null) {
			if (status.equalsIgnoreCase("approved")) {
				return new StatusDTO<List<QuestionResponseDTO>>("", true, utilities.convertQuestionListToQuestionResponseDTOList(questionRepository.findByQuestionContainingIgnoreCaseAndIsApprovedTrue(search)));
			}
			else {
				return new StatusDTO<List<QuestionResponseDTO>>("Question search only works with 'approved' status.", false, null);
			}
		}
		else if (search == null && topic != null) {
			if (status.equalsIgnoreCase("approved")) {
				return new StatusDTO<List<QuestionResponseDTO>>("", true, utilities.convertQuestionListToQuestionResponseDTOList(questionRepository.findByTopicContainingIgnoreCaseAndIsApprovedTrue(topic)));
			}
			else {
				return new StatusDTO<List<QuestionResponseDTO>>("Question search only works with 'approved' status.", false, null);
			}
		}
		else {
			if (status.equalsIgnoreCase("approved")) {
				return new StatusDTO<List<QuestionResponseDTO>>("", true, utilities.convertQuestionListToQuestionResponseDTOList(questionRepository.findByTopicContainingIgnoreCaseAndQuestionContainingIgnoreCaseAndIsApprovedTrue(topic, search)));
			}
			else {
				return new StatusDTO<List<QuestionResponseDTO>>("Question search only works with 'approved' status.", false, null);
			}
		}
	}

	@Override
	public StatusDTO<QuestionResponseDTO> getQuestionById(Long questionId) {
		Optional<Question> optionalQuestion = questionRepository.findById(questionId);
		if (optionalQuestion.isEmpty()) {
			return new StatusDTO<QuestionResponseDTO>("Question with ID " + questionId + " does not exist.", false, null);
		}
		return new StatusDTO<QuestionResponseDTO>("", true, utilities.convertQuestionToQuestionResponseDTO(optionalQuestion.get()));
	}

	@Override
	public StatusDTO<QuestionResponseDTO> createQuestion(QuestionRequestDTO questionRequestDTO, String postedBy) {
		Question question = new Question(questionRequestDTO.getQuestion(), questionRequestDTO.getTopic(), questionRequestDTO.getImages(), postedBy);
		Question savedQuestion = questionRepository.save(question);
		sendEmailNotification("New Question Posted","A new Questions has been posted on the platform. Please visit and approve the question.");
		return new StatusDTO<QuestionResponseDTO>("", true, utilities.convertQuestionToQuestionResponseDTO(savedQuestion));
	}
	
	@Override
	public StatusDTO<QuestionResponseDTO> updateQuestion(QuestionUpdateDTO questionUpdateDTO, Long questionId, String approvedBy) {
		Optional<Question> optionalQuestion = questionRepository.findById(questionId);
		if (optionalQuestion.isEmpty()) {
			return new StatusDTO<QuestionResponseDTO>("Question with ID " + questionId + " does not exist.", false, null);
		}
		Question question = optionalQuestion.get();
		question.setIsApproved(questionUpdateDTO.getIsApproved());
		question.setApprovedBy(approvedBy);
		return new StatusDTO<QuestionResponseDTO>("", true, utilities.convertQuestionToQuestionResponseDTO(questionRepository.save(question)));
	}
	
	@Override
	public StatusDTO<Boolean> deleteQuestionById(Long questionId) {
		Optional<Question> optionalQuestion = questionRepository.findById(questionId);
		if (optionalQuestion.isEmpty()) {
			return new StatusDTO<Boolean>("Question with id " + questionId + " does not exist.", false, null);
		}
		Question question = optionalQuestion.get();
		if (question.getIsApproved()) {
			return new StatusDTO<Boolean>("Cannot delete an approved question.", false, false);
		}
		questionRepository.delete(question);
		return new StatusDTO<Boolean>("", true, true);
	}
	
	private void sendEmailNotification(String subject,String text) {
		SimpleMailMessage message=new SimpleMailMessage();
		message.setTo("kavurumahendrachowdary@gmail.com");
		message.setSubject(subject);
		message.setText(text);
		mailSender.send(message);
	}

}
