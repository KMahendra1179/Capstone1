package com.example.demo.dto;

public class StatusDTO<T> {

    private String statusMessage;
    private boolean isValid;
    private T object;

    public String getStatusMessage() {
        return statusMessage;
    }

    public boolean getIsValid() {
        return isValid;
    }

    public T getObject() {
        return object;
    }

    // Constructor
    public StatusDTO(String statusMessage, boolean isValid, T object) {
        super();
        this.statusMessage = statusMessage;
        this.isValid = isValid;
        this.object = object;
    }

    // New isSuccess method
    public boolean isSuccess() {
        return isValid;
    }
}
