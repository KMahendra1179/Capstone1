package com.example.demo.dto;

import java.util.Date;

public class CommentResponseDTO {

    private Long id;
    private String comment;
    private String postedBy;
    private Date postedAt;

    public CommentResponseDTO(Long id, String comment, String postedBy, Date postedAt) {
        this.id = id;
        this.comment = comment;
        this.postedBy = postedBy;
        this.postedAt = postedAt;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public String getPostedBy() {
		return postedBy;
	}

	public void setPostedBy(String postedBy) {
		this.postedBy = postedBy;
	}

	public Date getPostedAt() {
		return postedAt;
	}

	public void setPostedAt(Date postedAt) {
		this.postedAt = postedAt;
	}

    
}
