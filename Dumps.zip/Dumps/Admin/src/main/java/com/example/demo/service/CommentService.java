package com.example.demo.service;

import com.example.demo.dto.CommentResponseDTO;
import com.example.demo.entity.Answer;
import com.example.demo.entity.Comment;
import com.example.demo.entity.User;
import com.example.demo.repository.AnswerRepository;
import com.example.demo.repository.CommentRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CommentService {

    @Autowired
    private CommentRepository commentRepository;

    @Autowired
    private AnswerRepository answerRepository;

    @Autowired
    private UserRepository userRepository;

    public CommentResponseDTO addComment(Long answerId, String comment, String username) {
        Answer answer = answerRepository.findById(answerId).orElseThrow(() -> new RuntimeException("Answer not found"));
        User user = userRepository.findByUsername(username).orElseThrow(() -> new RuntimeException("User not found"));
        Comment newComment = new Comment(comment, answer, user);
        commentRepository.save(newComment);
        return new CommentResponseDTO(newComment.getId(), newComment.getComment(), newComment.getPostedBy().getUsername(), newComment.getPostedAt());
    }

    public List<CommentResponseDTO> getCommentsByAnswerId(Long answerId) {
        List<Comment> comments = commentRepository.findByAnswerId(answerId);
        return comments.stream()
            .map(comment -> new CommentResponseDTO(comment.getId(), comment.getComment(), comment.getPostedBy().getUsername(), comment.getPostedAt()))
            .collect(Collectors.toList());
    }
}
