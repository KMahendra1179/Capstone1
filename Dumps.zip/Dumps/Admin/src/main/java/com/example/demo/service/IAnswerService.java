package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.AnswerRequestDTO;
import com.example.demo.dto.AnswerResponseDTO;
import com.example.demo.dto.AnswerUpdateDTO;
import com.example.demo.dto.StatusDTO;

public interface IAnswerService {
	
	public StatusDTO<List<AnswerResponseDTO>> getAllAnswers(String answerStatus);
	public StatusDTO<List<AnswerResponseDTO>> getAllAnswersForQuestionId(Long questionId, String answerStatus);
	public StatusDTO<AnswerResponseDTO> createAnswerForQuestionId(Long questionId, AnswerRequestDTO answerRequestDTO, String postedBy);
	public StatusDTO<AnswerResponseDTO> updateAnswerForQuestionId(Long questionId, Long answerId, AnswerUpdateDTO answerUpdateDTO, String approvedBy);
	public StatusDTO<Boolean> deleteAnswerForQuestionById(Long questionId, Long answerId);
	// New Methods for Like Feature
    //public StatusDTO<AnswerResponseDTO> likeAnswer(Long answerId, String likedBy);

    //public StatusDTO<AnswerResponseDTO> unlikeAnswer(Long answerId, String unlikedBy);
    // Add to IAnswerService
    public StatusDTO<AnswerResponseDTO> likeAnswer(Long answerId, String username);

    public StatusDTO<AnswerResponseDTO> unlikeAnswer(Long answerId, String username);
}
