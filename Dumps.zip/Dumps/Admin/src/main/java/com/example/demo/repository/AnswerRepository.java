package com.example.demo.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.Answer;

@Repository
public interface AnswerRepository extends JpaRepository<Answer, Long> {
	boolean existsById(Long id);
	List<Answer> findByIsApprovedTrue();
	List<Answer> findByIsApprovedFalse();
	
	List<Answer> findByQuestionId(Long questionId);
	Optional<Answer> findByIdAndQuestionId(Long answerId, Long questionId);
	
	List<Answer> findByQuestionIdAndIsApprovedTrue(Long questionId);
	List<Answer> findByQuestionIdAndIsApprovedFalse(Long questionId);
	// Method to increment like count
    @Modifying
    @Transactional
    @Query("UPDATE Answer a SET a.likeCount = a.likeCount + 1 WHERE a.id = ?1")
    void incrementLikeCount(Long answerId);

    // Method to decrement like count
    @Modifying
    @Transactional
    @Query("UPDATE Answer a SET a.likeCount = a.likeCount - 1 WHERE a.id = ?1 AND a.likeCount > 0")
    void decrementLikeCount(Long answerId);

}
