package com.example.demo.controller;

import com.example.demo.dto.CommentResponseDTO;
import com.example.demo.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/comments")
public class CommentController {

    @Autowired
    private CommentService commentService;

    @PostMapping("/{answerId}")
    public CommentResponseDTO addComment(@PathVariable Long answerId, @RequestBody String comment, @RequestParam String username) {
        return commentService.addComment(answerId, comment, username);
    }

    @GetMapping("/{answerId}")
    public List<CommentResponseDTO> getComments(@PathVariable Long answerId) {
        return commentService.getCommentsByAnswerId(answerId);
    }
}
