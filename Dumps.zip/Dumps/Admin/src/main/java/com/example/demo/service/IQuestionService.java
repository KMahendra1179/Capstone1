package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.QuestionRequestDTO;
import com.example.demo.dto.QuestionResponseDTO;
import com.example.demo.dto.QuestionUpdateDTO;
import com.example.demo.dto.StatusDTO;

public interface IQuestionService {
	
	public StatusDTO<List<QuestionResponseDTO>> getAllQuestions(String status, String search, String topic);
	public StatusDTO<QuestionResponseDTO> getQuestionById(Long questionId);
	public StatusDTO<QuestionResponseDTO> createQuestion(QuestionRequestDTO questionRequestDTO, String postedBy);
	public StatusDTO<QuestionResponseDTO> updateQuestion(QuestionUpdateDTO questionUpdateDTO, Long questionId, String approvedBy);
	public StatusDTO<Boolean> deleteQuestionById(Long questionId);

}
