package com.wipro.cp.doconnectchat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoConnectChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
