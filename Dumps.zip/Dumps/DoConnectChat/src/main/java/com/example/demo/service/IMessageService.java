package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.MessageRequestDTO;
import com.example.demo.dto.MessageResponseDTO;

public interface IMessageService {
	
	public List<MessageResponseDTO> getAllMessages();
	
	public boolean createMessage(MessageRequestDTO messageRequestDTO);

}
